# ShopDienThoai
Đây là project website bán điện thoại.
Được xây dựng với HTML, CSS, JS, BS, JQERY.
